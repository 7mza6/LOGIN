import 'package:flutter/material.dart';
import 'package:users/Views/theam.dart';
import 'package:users/auth/models/userModel.dart';

import '../main.dart';

class DrawerView extends StatefulWidget {
  DrawerView({super.key,required });

  @override
  State<DrawerView> createState() => _DrawerViewState();
}

class _DrawerViewState extends State<DrawerView> {
  // State for managing the Dark Mode switch
  bool _isDarkModeOn = false;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        // Remove padding from the ListView
        padding: EdgeInsets.zero,
        children: [
          // 1. Header Section
          _buildHeader(),
          
          // 2. User Info Card
          _buildUserInfoCard(),

          // 3. Menu Items

          _buildNotificationsItem(),
          _buildDarkModeItem(),
          _buildMenuItem(
            icon: Icons.info_outline,
            text: 'About',
            onTap: () {
              Navigator.pushNamed(context, '/about');
            },
          ),
          
          // 4. Divider
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.0),
            child: Divider(color: Colors.black26),
          ),
          
          // 5. Logout Button
          _buildLogoutItem(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20,10, 20, 10),
      child: Row(
        children: [
          const CircleAvatar(
            radius: 25,
           backgroundImage: NetworkImage('https://images-platform.99static.com/nK0Z_sdR6pVTLL97Gq1z5TkG3vQ=/102x102:921x921/500x500/top/smart/99designs-contests-attachments/71/71057/attachment_71057015',), // Placeholder color
            // backgroundImage: AssetImage('assets/logo.png'), 
          ),
          const SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'My App',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Text(
                'Navigation Menu',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUserInfoCard() {
   
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 10.0),
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F4FD), 
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: const CircleAvatar(
          radius: 25,
          backgroundImage: NetworkImage('https://s3.nyeki.dev/nekos-api/images/original/a0ffd211-ecea-4b6f-ad1d-dabea006a7f7.webp'),
          
        ),
        title: Text(
          CurrentUser.getcurrentUser()?.username??'User Name',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String text,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue.shade800),
      title: Text(text, style: const TextStyle(fontWeight: FontWeight.w500)),
      onTap: onTap,
    );
  }

  Widget _buildNotificationsItem() {
    return ListTile(
      leading: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(Icons.notifications, color: Colors.blue.shade800),
        ],
      ),
      title: const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w500)),
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.red,
          borderRadius: BorderRadius.circular(10),
        ),
        child: const Text('5', style: TextStyle(color: Colors.white, fontSize: 12)),
      ),
      onTap: () {
        Navigator.pushNamed(context, '/notifications');
      },
    );
  }

  Widget _buildDarkModeItem() {
    return ListTile(
      leading: Icon(Icons.dark_mode, color: Colors.blue.shade800),
      title: const Text('Dark Mode', style: TextStyle(fontWeight: FontWeight.w500)),
      trailing: Switch(
        value: getThemeMode() == ThemeMode.dark?true:false,
        onChanged: (value) {
          setState(() {
             if(value){
              setThemeMode(ThemeMode.dark);
             MyApp.of(context)?.setThemeMode(ThemeMode.dark);
             }else{
              setThemeMode(ThemeMode.light);
              MyApp.of(context)?.setThemeMode(ThemeMode.light);
             }
          });
        },
        activeColor: Colors.blue.shade800,
      ),
    );
  }

  Widget _buildLogoutItem() {
    return ListTile(
      leading: const Icon(Icons.logout, color: Colors.red),
      title: const Text(
        'Logout',
        style: TextStyle(color: Colors.red, fontWeight: FontWeight.w500),
      ),
      onTap: () {
        Navigator.pushNamed(context, '/login');
      },
    );
  }
}