import 'package:flutter/material.dart';
import 'package:flex_color_scheme/flex_color_scheme.dart';


ThemeMode themeMode = ThemeMode.light;

setThemeMode(ThemeMode mode) {
  themeMode = mode; 
}
ThemeMode getThemeMode() {
  return themeMode;
}

final lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: const ColorScheme.light(
      primary: Color(0xFF0D47A1), // Dark Blue (same as darkTheme)
      secondary: Color(0xFF1976D2), // Medium Blue
      background: Color(0xFFF5F5F5),
      surface: Colors.white,
    ));

final darkTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  colorScheme: const ColorScheme.dark(
    primary: Color(0xFF0D47A1),      // Dark Blue
    secondary: Color(0xFF1976D2),    // Lighter Blue
    background: Color(0xFF121212),
    surface: Color(0xFF1E1E1E),
  ),
  scaffoldBackgroundColor: const Color(0xFF121212),
  appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFF0D47A1),
    foregroundColor: Colors.white,
  ),
);
