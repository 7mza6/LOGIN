

import 'package:flutter/material.dart';

PreferredSizeWidget AppHeader() {
  return AppBar(
    centerTitle: true,
    title: Text('AppHeader'),
   actions: [
      IconButton(
        icon: Icon(Icons.notifications),
        onPressed: () {
          // Do something when the search icon is pressed
        },
      ),
    ],
  );
}
