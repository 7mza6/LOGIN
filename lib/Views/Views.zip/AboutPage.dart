import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart'; 

Widget AboutPage(BuildContext context) {
  return SingleChildScrollView(
    padding: const EdgeInsets.all(20.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        // App Logo/Icon
        Image.network(
          'https://images-platform.99static.com/nK0Z_sdR6pVTLL97Gq1z5TkG3vQ=/102x102:921x921/500x500/top/smart/99designs-contests-attachments/71/71057/attachment_71057015', // Make sure you have an image in your assets folder
          height: 120,
          width: 120,
          fit: BoxFit.contain,
        ),
        const SizedBox(height: 20),

        // App Name
        Text(
          'Student App',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple,
              ),
        ),
        const SizedBox(height: 10),

        // App Version
        Text(
          'Version 1.0.0',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Colors.grey[700],
              ),
        ),
        const SizedBox(height: 30),

        // Description of the App
        Text(
          'Welcome to Student App! This app helps you manage your assignments, quizzes, courses, and schedule — all in one place.It’s built to make it easier for you to stay organized and keep track of your academic tasks.Simple, clear, and useful.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        const SizedBox(height: 30),

        // Developer Information
        _buildSectionTitle(context, 'Developed By'),
        const SizedBox(height: 10),
        Text(
          'Hamza Sayes',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 5),
        Text(
          '© 2025 All rights reserved.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
        ),
        const SizedBox(height: 30),

        _buildSectionTitle(context, 'Connect With Us'),
        const SizedBox(height: 10),
        _buildLinkTile(
          context,
          icon: Icons.facebook,
          title: 'Facebook',
          url: 'https://www.facebook.com/hamza.msayes.5',
        ),
        _buildLinkTile(
          context,
          icon:FontAwesomeIcons.instagram,
          title: 'Instagram',
          url: 'https://www.instagram.com/hamza.sayes/',
        ),
        _buildLinkTile(
          context,
          icon: Icons.email,
          title: 'Contact Support',
          url: 'mailto:hamza.sayes@students.alquds.edu',
        ),
        const SizedBox(height: 30),

        _buildSectionTitle(context, 'Acknowledgments'),
        const SizedBox(height: 10),
        Text(
          'This app uses various open-source libraries. You can view their licenses by tapping "Licenses" below.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        const SizedBox(height: 10),
        ElevatedButton.icon(
          icon: const Icon(Icons.info_outline),
          label: const Text('View Licenses'),
          onPressed: () {
            showLicensePage(
              context: context,
              applicationName: 'Student App',
              applicationVersion: '1.0.0',
              applicationLegalese: '© 2025 Alquds University',
            );
          },
        ),
        const SizedBox(height: 20),
      ],
    ),
  );
}


Widget _buildSectionTitle(BuildContext context, String title) {
  return Text(
    title,
    style: Theme.of(context).textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.bold,
          color: Colors.blueAccent,
        ),
  );
}

Widget _buildLinkTile(BuildContext context, {required IconData icon, required String title, required String url}) {
  return Card(
    margin: const EdgeInsets.symmetric(vertical: 5),
    elevation: 2,
    child: ListTile(
      leading: Icon(icon, color: Colors.blueAccent),
      title: Text(title),
      trailing: const Icon(Icons.chevron_right),
      onTap: () async {
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Could not open $title')),
          );
        }
      },
    ),
  );
}